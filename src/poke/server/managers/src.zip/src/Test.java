
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
long time = System.currentTimeMillis();
		Grayscale.applyMask("chk1.jpg");
		Grayscale.applyMask("chk2.jpg");
		Grayscale.applyMask("chk3.jpg");
		Grayscale.applyMask("chk4.jpg");
		Grayscale.applyMask("chk5.jpg");
		Grayscale.applyMask("chk6.jpg");
		System.out.println("TT : " + (System.currentTimeMillis()-time));
	}

}
